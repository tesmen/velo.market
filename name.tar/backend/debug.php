<div style="border: 1px solid black">
<u>DEBUG</u><br>
<?
echo 'SESSION: ';
var_dump($_SESSION);
?>
</div>