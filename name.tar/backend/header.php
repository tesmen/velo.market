﻿<?
$_SESSION['current_page']= $_SERVER['REQUEST_URI'] ;
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">
<head>
<meta charset="utf-8">
<link type="text/css" href="/css/style.css" rel="stylesheet"/>
<link type="text/css" href="/css/bootstrap.css" rel="stylesheet"/>
<script src="/js/bootstrap.min.js"></script>
<title>NULL</title>
</head>
<body>